#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>

int main() {
    pid_t a = fork();
    pid_t b = fork();

    if(a > 0 && b > 0) {
        printf("P with id: %d\n", getpid());
    }

    else if(a > 0 && b == 0) {
        printf("C2 with id: %d\n", getpid());
    }

    else if(a == 0 && b > 0) {
        printf("C1 with id: %d\n", getpid());
        printf("My parent is: %d\n", getppid());
    }

    else {
        printf("C21 with id: %d\n", getpid());
        // printf("My parent is: %d\n", getppid());
    }

    return 0;
}