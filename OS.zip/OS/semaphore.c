#include <stdio.h>
#include <semaphore.h>
#include <sys/types.h>
#include <pthread.h>

sem_t sem;
int count = 0;

void *func() {
    for(int i = 0; i < 100000; i++) {
        sem_wait(&sem);
        count++;
        sem_post(&sem);
    }
}

int main() {
    int ret = sem_init(&sem, 0, 1);
    pthread_t t1, t2;

    if(ret == 0) {

        // successfully initialized semaphore
        if(pthread_create(&t1, NULL, func, NULL)) {
            printf("Failed to create thread t1\n");
        }

        if(pthread_create(&t2, NULL, func, NULL)) {
            printf("Failed to create thread t2\n");
        }

        pthread_join(t1, NULL);
        pthread_join(t2, NULL);

        printf("%d\n", count);

    } else {

        // failed to initialize semaphore
        printf("Failed to initialize semaphore\n");
    }
    return 0;
}