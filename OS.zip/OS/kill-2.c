/*

Syntax: int kill(pid_t pid, int sig);
Header file: #include <signal.h>
Type: system call

Description:

- The kill() function shall send a signal to a process or a group of processes specified by pid. The signal to be sent is specified by sig and is either one from the list given in <signal.h> or 0. If sig is 0 (the null signal), error checking is performed but no signal is actually sent. The null signal can be used to check the validity of pid.

- If pid is greater than 0, sig shall be sent to the process whose process ID is equal to pid.

- If pid is 0, sig shall be sent to all processes (excluding an unspecified set of system processes) whose process group ID is equal to the process group ID of the sender, and for which the process has permission to send a signal.

- If pid is -1, sig shall be sent to all processes (excluding an unspecified set of system processes) for which the process has permission to send that signal.

*/

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    pid_t pid = fork();

    if (pid > 0) {
        printf("Parent started\n");
        kill(pid, SIGCONT);
    }

    else {
        printf("Child process 1\n");
        printf("Child process 2\n");
        printf("Child process 3\n");
        printf("Child process 4\n");
        printf("Child process 5\n");
        printf("Child process 6\n");
        printf("Child process 7\n");
        printf("Child process 8\n");
    }    

    return 0;
}