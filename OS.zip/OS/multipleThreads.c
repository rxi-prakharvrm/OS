#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>

pthread_mutex_t mutex;

void *printThreads(void *i) {
    pthread_mutex_lock(&mutex);
    printf("%d -> %lu\n",* (int *) i, pthread_self());
    pthread_mutex_unlock(&mutex);
}

int main() {
    pthread_mutex_init(&mutex, NULL);
    pthread_t t[10];

    for(int i = 1; i <= 10; i++) {
        pthread_create(&t[i], NULL, printThreads, i);
    }

    for(int i = 1; i <= 10; i++) {
        pthread_join(t[i], NULL);
    }

    return 0;
}