#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

int main() {
    int fd;
    fd = open("example.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if(fd == -1) {
        printf("Error occurred!\n");
    }
    return 0;
}