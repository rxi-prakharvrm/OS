#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

int main() {
    int fd = creat("example.txt", S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if(fd == -1) {
        printf("Error occurred!\n");
    }
    return 0;
}