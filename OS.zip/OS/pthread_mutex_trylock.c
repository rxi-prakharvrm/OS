#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
// #include <sys/types.h>
int count = 0;
pthread_mutex_t m;

void *inc() {
    for(int i = 0; i < 100000; i++) {
        pthread_mutex_lock(&m);
        count++;
        pthread_mutex_trylock(&m);
        pthread_mutex_unlock(&m);
    }
}

void *dec() {
    for(int i = 0; i < 100000; i++) {
        pthread_mutex_lock(&m);
        count--;
        pthread_mutex_unlock(&m);
    }
}

int main() {
    for(int i = 0; i < 20; i++) {
        pthread_mutex_init(&m, NULL);
        pthread_t t1, t2;
        pthread_create(&t1, NULL, inc, NULL);
        pthread_create(&t2, NULL, dec, NULL);
        pthread_join(t1, NULL);
        pthread_join(t2, NULL);
        printf("%d\n", count);
        pthread_mutex_destroy(&m);
    }
    return 0;
}