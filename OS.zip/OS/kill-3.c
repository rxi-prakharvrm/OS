#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>

void handle_sigint(int sig) {}

int main() {
    pid_t pid = fork();

    if (pid > 0) {
        printf("Parent process started\n");
        printf("Parent process end\n");
        kill(pid, SIGABRT);
    }
    
    else {
        for(int i = 0; i < 100; i++) {
            printf("Child process started\n");
            printf("Child process end\n");
        }
    }

    return 0;
}