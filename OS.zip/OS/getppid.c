#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>

int main() {
    pid_t pid = fork();

    if(pid > 0) {
        printf("Parent process with process id: %d\n", getpid());
    }

    else if(pid == 0) {
        printf("Child process with process id: %d\n", getpid());
        printf("My parent process with process id: %d\n", getppid());
    }

    else {
        printf("Error occurred!, Child not created\n");
    }

    return 0;
}