// Description:

// - If pid is equal to (pid_t)-1, status is requested for any child process. In this respect, waitpid() is then equivalent to wait().

// - If pid is greater than 0, it specifies the process ID of a single child process for which status is requested.

// - If pid is 0, status is requested for any child process whose process group ID is equal to that of the calling process.

// - If pid is less than (pid_t)-1, status is requested for any child process whose process group ID is equal to the absolute value of pid.


#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main() {
    int a = fork();
    int b = fork();
    int *status = (int *)malloc(2);
     
    if(a > 0 && b > 0) {
    // printf("P %d, %d\n", a, b);
    printf("P with id: %d\n", getpid());
    // int r = waitpid(b, status, 0);
    // printf("Status is: %d\n", *status/256);
    // printf("Terminated child id: %d\n", r);
    printf("===================================\n");
    }
    
    else if(a > 0 && b == 0) {
    // printf("C2 %d, %d\n", a, b);
    printf("C2 with id: %d\n", getpid());
    exit(1);
    }
    
    else if(a == 0 && b > 0) {
    // printf("C1 %d, %d\n", a, b);
    printf("C1 with id: %d\n", getpid());
    }
    
    else if(a == 0 && b == 0) {
    // printf("C21 %d, %d\n", a, b);
    printf("C21 with id: %d\n", getpid());
    int r = wait(status);
    printf("%d\n", r);
    }

    return 0;
}
