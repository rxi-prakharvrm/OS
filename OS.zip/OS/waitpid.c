// Description:

// - If pid is equal to (pid_t)-1, status is requested for any child process. In this respect, waitpid() is then equivalent to wait().

// - If pid is greater than 0, it specifies the process ID of a single child process for which status is requested.

// - If pid is 0, status is requested for any child process whose process group ID is equal to that of the calling process.

// - If pid is less than (pid_t)-1, status is requested for any child process whose process group ID is equal to the absolute value of pid.


#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

int main() {
    pid_t pid = fork();
    
    int *status = (int *)malloc(2);

    if(pid > 0) {
        printf("Here inside the parent process, pid is equals to child id: %d\n", pid);
        printf("Parent process with process id: %d\n", getpid());
        pid_t exitChildPid = waitpid(-1, status, 0);
        printf("%d\n", *status/256);
        printf("%d\n", exitChildPid);
    }

    else if(pid == 0) {
        printf("Child process with id: %d\n", getpid());
        printf("Before exit\n");
        exit(1);
        printf("After exit\n");
    }

    return 0;
}