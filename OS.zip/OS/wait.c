// My id is: 100

#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

int main() {
    pid_t pid = fork();
    int *status = (int *)malloc(2);

    if(pid > 0) {
        printf("Here inside the parent process, pid is equals to child id: %d\n", pid);
        printf("Parent process with process id: %d\n", getpid());
        pid_t exitChildPid = wait(status);
        printf("%d\n", *status/256);
        printf("%d\n", exitChildPid);
    }

    else if(pid == 0) {
        printf("Child process with id: %d\n", getpid());
        printf("Before exit\n");
        exit(1);
        printf("After exit\n");
    }

    return 0;
}