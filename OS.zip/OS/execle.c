#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    printf("Executing ls command using execle with a custom environment:\n");
    
    // Define a custom environment
    char *envp[] = {"PATH=/bin", NULL};

    // Execute the ls command with execle
    execle("/bin/ls", "ls", "-h", NULL, envp);

    // execle() will only return if an error occurs
    perror("execle");
    return 1;
}
