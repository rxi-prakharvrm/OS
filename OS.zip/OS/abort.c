/*

Syntax: void abort(void);
Header file: #include <stdlib.h>
Type: standard library function

Description:

- The abort() function causes abnormal process termination to occur, unless the signal SIGABRT is being caught and the signal handler does not return. The abnormal termination processing includes at least the effect of fclose() on all open streams, and message catalogue descriptors, and the default actions defined for SIGABRT. The SIGABRT signal is sent to the calling process as if by means of raise() with the argument SIGABRT.

- The status made available to wait() or waitpid() by abort() will be that of a process terminated by the SIGABRT signal. The abort() function will override blocking or ignoring the SIGABRT signal.

*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>

int main() {
    pid_t pid = fork();

    if (pid > 0) {
        printf("Parent process started\n");
        printf("Parent process end\n");
    }
    
    else {
        printf("Child process started\n");
        abort();
        printf("Child process end\n"); // this statement will not run
    }

    return 0;
}