    // -l: Lists files in long format.
    // -a: Lists all files, including hidden files (those whose names begin with a dot).
    // -h: Prints file sizes in human-readable format.
    // -t: Sorts files by modification time, with the newest first.
    // -r: Reverses the order of sorting.

    // If execl() fails, it returns -1 and sets the errno variable appropriately. In this case, we use perror() to print an error message indicating what went wrong.
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    printf("Executing ls command using execl:\n");
    
    // Execute the ls command with execl
    execl("/bin/ls", "ls", "-h", NULL);

    // execl() will only return if an error occurs
    perror("execl");
    return 1;
}
