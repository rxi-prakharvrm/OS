/*

Name: atexit()
Header file: #include <stdlib.h>
Type: standard library function

Description:

- The atexit() function shall register the function pointed to by func, to be called without arguments at normal program termination.

*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

void exitFunction() {
    printf("function called by 'atexit()' is running\n");
}

int main() {
    pid_t pid = fork();
    int *exitStatus = (int *)malloc(2);
    
    if (pid > 0) {
        printf("Parent process before wait\n");
        wait(exitStatus);
        printf("Exit status of child process is: %d\n", *exitStatus/256);
    }

    else {
        printf("Child process\n");
        atexit(exitFunction);

        // it will call atexit() function
        // exit(1);

        // it will not call atexit() function
        // _exit(1);

        // it will not call atexit() function
        _Exit(1);
    }


    return 0;
}