#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void *inc() {
    printf("inc function id: %u\n", pthread_self());
    pthread_exit(NULL);
    printf("After pthread_exit\n"); // This statement will never run

}

void *dec() {
    printf("dec function id: %u\n", pthread_self());
}

int main() {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, inc, NULL);
    pthread_create(&t2, NULL, dec, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    return 0;
}