#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

int count = 0;
sem_t s;

void *inc() {
    for(int i = 0; i < 100000; i++) {
        sem_wait(&s);
        count++;
        sem_trywait(&s);
        sem_post(&s);
    }
}

void *dec() {
    for(int i = 0; i < 100000; i++) {
        sem_wait(&s);
        count--;
        sem_post(&s);
    }
}

int main() {
    sem_init(&s, 0, 1);
    for(int i = 0; i < 20; i++) {
        pthread_t t1, t2;
        pthread_create(&t1, NULL, inc, NULL);
        pthread_create(&t2, NULL, dec, NULL);
        pthread_join(t1, NULL);
        pthread_join(t2, NULL);
        printf("%d\n", count);
    }
    sem_destroy(&s);
    return 0;
}
